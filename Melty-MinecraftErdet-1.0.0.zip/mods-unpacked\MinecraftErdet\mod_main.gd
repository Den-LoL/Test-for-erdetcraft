extends Node

const MOD_ID := "Melty-MinecraftErdet"

func _init() -> void:
	print("[MinecraftErdet] Mod initializing...")

func _ready() -> void:
	print("[MinecraftErdet] Mod loaded successfully!")
	print("[MinecraftErdet] Installing script extension...")
	var path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/minecraft_system.gd")
	ModLoaderMod.install_script_extension(path)
	print("[MinecraftErdet] Script extension installed!")
